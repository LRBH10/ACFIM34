<div class="container">

    <hr>

    <footer>
        <div class="row">
            <div class="pull-right col-lg-12">
                <p>Copyright &copy; Association Culturelle Franco-Iranienne de Montpellier (ACFIM)  2014</p>
            </div>
        </div>
    </footer>

</div>