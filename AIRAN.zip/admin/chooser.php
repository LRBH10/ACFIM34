<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
?>

<section class="container">
  <div class="row">
    <div class =" col-md-3">
      <a href="admin.php?kind=members" class="well " > Gestions des  Members </a>
    </div>
    <div class =" col-md-3">
      <a href="admin.php?kind=events" class="well" > Gestions des  Evenement </a>
    </div>
    
    <div class =" col-md-3">
      <a href="admin.php?kind=news" class="well" > Gestions des  News </a>
    </div>
    
    <div class =" col-md-3">
      <a href="admin.php?kind=services" class="well" > Gestions des  Services </a>
    </div>
    
    
    
    
  </div>
  
  
</section>
