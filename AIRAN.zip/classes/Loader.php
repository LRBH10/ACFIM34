<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Loeder
 *
 * @author Rabah
 */
include_once './classes/Member.php';
include_once './classes/Event.php';
include_once './classes/News.php';
include_once './classes/Service.php';
include_once './classes/dbManager.php';

function dumber($param) {
  echo '<pre>';
  var_dump($param);
  echo '</pre>';
}

?>
